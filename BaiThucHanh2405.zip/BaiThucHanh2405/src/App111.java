import java.util.Scanner;
import java.util.LinkedList;
public class App111 {
    public static void main(String[] args) {
        int n; 
        int node; 
        int sum =0;
        int count =0;
        Scanner sc=new Scanner(System.in);
        LinkedList<Integer> linkedListIntegers=new LinkedList<>();
        System.out.print("nhap so phan tu cua list");
        n=sc.nextInt();
        for (int i = 0; i < n; i++) {
            node=sc.nextInt();
            linkedListIntegers.add(node);
        }
        for (int i = 0; i < n; i++) {
            if (linkedListIntegers.get(i)%2==0) {
                sum+=linkedListIntegers.get(i);
                count++;
            }
        }
        tbCongSoChan = sum/count;
        System.out.print("trung binh cong cac so chan trong list");
        sc.close();
    }
}
