import java.util.Iterator;
import java.util.LinkedList;
import java.util.Scanner;
public class App112 {
    public static void main(String[] args) {
        String tenSinhVien,thongTin=null;
        String arrThongTin[];
        double diemSinhVien;
        LinkedList<String> danhsachSV=new LinkedList<>();
        LinkedList<String> svThiLai=new LinkedList<>();
        LinkedList<String> svDiemCao=new LinkedList<>();
        LinkedList<String> svCanTim=new LinkedList<>();
        Scanner sc=new Scanner(System.in);
        do {
            System.out.println("nhap vao ten sinh vien");
            tenSinhVien=sc.nextLine();
            if (!tenSinhVien.isEmpty()) {
                System.out.println("nhap vao diem sinh vien");
                diemSinhVien=Double.parseDouble(sc.nextLine());
                thongTin=tenSinhVien+""+diemSinhVien;
                danhsachSV.add(thongTin);
            }
        } while (!tenSinhVien.isEmpty());
        System.out.print("so sinh vien co trong danh sach="+(danhsachSV.size()));
        System.out.print("thong tin cua cac sinh vien vua nhap la");
        System.out.print("ten sinh vien");
        Iterator<String> iterator=danhsachSV.iterator();
        while (iterator.hasNext()) {
            System.out.print(iterator.next());
        }
        for (int i = 0; i < danhsachSV.size(); i++) {
            String sv=danhsachSV.get(i);
            arrThongTin=sv.split("");
            Double point=Double.parseDouble(arrThongTin[1]);
            if (point<=5) {
                svThiLai.add(sv);
            }
        }
        if (svThiLai.isEmpty()) {
            System.out.print("khong co sinh vien phai thi lai");
        }else{
            System.out.print("so sinh vien phai thi lai ="+(svThiLai.size()));
            System.out.println("thong tin cua cac sinh vien phai thi lai la");
            System.out.println("Ten sinh vien\t diem");
            iterator=svThiLai.iterator();
            while (iterator.hasNext()) {
                System.out.println(iterator.next());
            }
        }
        double maxTemp =0;
        int i=0;
        while (i<danhsachSV.size()) {
            arrThongTin=danhsachSV.get(i).split("\t");
            if (Double.parseDouble(arrThongTin[1])>=maxTemp) {
                maxTemp=Double.parseDouble(arrThongTin[1]);
            }
            i++;
        }
        i=0;
        while (i<danhsachSV.size()) {
            arrThongTin=danhsachSV.get(i).split("\t");
            if (Double.parseDouble(arrThongTin[1])==maxTemp){
                svDiemCao.add(danhsachSV.get(i));
            }
            i++;
            }
            System.out.println("thong tin cua cac sinh vien co diem cao nhat la");
            System.out.println("ten sinh vien");
            iterator=svDiemCao.iterator();
            while (iterator.hasNext()) {
                System.out.println(iterator.next());
            }
            System.out.print("nhap ten sinh vien can tim ");
            String search =sc.nextLine();
            i=0;
            while (i<danhsachSV.size()) {
                arrThongTin=danhsachSV.get(i).split("\t");
                tenSinhVien=arrThongTin[0];
                if (search.equalsIgnoreCase(tenSinhVien)) {
                    svCanTim.add(danhsachSV.get(i));
                }
                i++;
            }
            System.out.println("thong tin cac sinh vien ten la"+search+"");
            System.out.println("ten sinh vien\t diem");
            iterator=svCanTim.iterator();
            while (iterator.hasNext()) {
                System.out.print(iterator.next());
            }sc.close();
        }
    }

