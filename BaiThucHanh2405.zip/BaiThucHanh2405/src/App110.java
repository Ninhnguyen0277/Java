import java.util.ArrayList;
import java.util.Comparator;
import java.util.Scanner;
public class App110 {
    public static void main(String[] args) {
        int n;
        int number;
        ArrayList<Integer> arrayListIntegers= new ArrayList<>();
        Scanner sc=new Scanner(System.in);
        System.out.println("nhap so phan tu cua arr");
        n=sc.nextInt();
        for (int i = 0; i < n; i++) {
            System.out.println("nhap phan tu thu"+i+"");
            number=sc.nextInt();
            arrayListIntegers.add(number);
        }
        int max= arrayListIntegers.get(0);
        for (int i = 0; i < arrayListIntegers.size(); i++) {
            if (arrayListIntegers.get(i).compareTo(max)>0) {
                max=arrayListIntegers.get(i);
            }
        }
        sc.close();
        System.out.println("cac phan tu co trong arrlist la");
        System.out.println(arrayListIntegers);
        System.out.println("phan tu trong arrlistinteger lon nhat la");
        System.out.println(max);
        System.out.println("Nhap phan tu can xoa: ");
        number = sc.nextInt();
        for(int i = 0; i < arrayListIntegers.size(); i++) {
          if(arrayListIntegers.get(i) == number) {
            arrayListIntegers.remove(number);
          }
        }
        System.out.println("arrayList sau khi xoa:");
        System.out.println(arrayListIntegers);
    
        arrayListIntegers.sort(Comparator.naturalOrder());
        System.out.println("arrayList sau khi sap xep:");
        System.out.println(arrayListIntegers);
        sc.close();
        } 
    }

