package com.na.colections.list;
public class App24 {
    public static void main(String[] args) {
        
    }
}
