package com.na.colections.list;
import java.util.ArrayList;

public class App21 {
    public static void main(String[] args) {
        ArrayList<String> colors=new ArrayList<>(3);
        colors.add("Red");
        colors.add("Blue");
        colors.add("Green");
        colors.add("Orange");
        colors.add("Green");
        colors.add("Pink");
        colors.add("Yelllow");
        System.out.println(colors.get(1));
        System.out.println(colors.contains("Orange"));
        System.out.println(colors.size());
        System.out.println(colors);
    }
}
